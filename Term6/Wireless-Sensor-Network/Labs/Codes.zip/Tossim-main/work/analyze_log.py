#!/usr/bin/env python3
import argparse
import re
import sys
from collections import defaultdict


TICKS_PER_SECOND_RE = re.compile(r"\bSIM TICKS_PER_SECOND value=(?P<value>\d+)\b")
PHASE_RE = re.compile(r"\bSIM PHASE\b(?P<fields>.*)$")
EVENT_RE = re.compile(
    r"\bAPP (?P<kind>REQUEST_SEND|RESPONSE_RECV|DATA_SEND|DATA_FORWARD|DATA_DELIVERED|DATA_DROP)\b(?P<fields>.*)$"
)
FIELD_RE = re.compile(r"\b(?P<key>[a-z_]+)=(?P<value>[-A-Za-z0-9_.]+)\b")
INTEGER_RE = re.compile(r"^-?\d+$")
FLOAT_RE = re.compile(r"^-?\d+\.\d+$")


def _parse_value(value):
    if INTEGER_RE.match(value):
        return int(value)
    if FLOAT_RE.match(value):
        return float(value)
    return value


def _parse_fields(text):
    return {
        match.group("key"): _parse_value(match.group("value"))
        for match in FIELD_RE.finditer(text)
    }


def _request_key(fields):
    return (fields["src"], fields["dst"], fields["seq"])


def _data_key(fields):
    return (fields["origin"], fields.get("data_type", 0), fields["seq"])


def _new_bucket():
    return {
        "sent": 0,
        "delivered": 0,
        "latencies_ticks": [],
        "hops": [],
    }


def _add_sent(bucket):
    bucket["sent"] += 1


def _add_delivery(bucket, latency, hops):
    bucket["delivered"] += 1
    bucket["latencies_ticks"].append(latency)
    bucket["hops"].append(hops)


def _bucket_summary(bucket, ticks_per_second):
    delivered = bucket["delivered"]
    sent = bucket["sent"]
    latencies = bucket["latencies_ticks"]
    hops = bucket["hops"]
    average_latency_ticks = float(sum(latencies)) / delivered if delivered else 0.0
    average_latency_ms = None
    if ticks_per_second:
        average_latency_ms = average_latency_ticks * 1000.0 / ticks_per_second
    average_hops = float(sum(hops)) / delivered if delivered else 0.0
    return {
        "sent": sent,
        "delivered": delivered,
        "packet_reception_rate": float(delivered) / sent if sent else 0.0,
        "latencies_ticks": latencies,
        "average_latency_ticks": average_latency_ticks,
        "average_latency_ms": average_latency_ms,
        "hops": hops,
        "average_hops": average_hops,
    }


def _analyze_request_response(lines, ticks_per_second):
    requests = {}
    latencies = []

    for line in lines:
        event_match = EVENT_RE.search(line)
        if not event_match:
            continue

        kind = event_match.group("kind")
        if kind not in {"REQUEST_SEND", "RESPONSE_RECV"}:
            continue

        fields = _parse_fields(event_match.group("fields"))
        required = {"time", "src", "dst", "seq"}
        if not required.issubset(fields):
            continue

        if kind == "REQUEST_SEND":
            requests[_request_key(fields)] = fields["time"]
        elif kind == "RESPONSE_RECV":
            request_key = (fields["dst"], fields["src"], fields["seq"])
            sent_time = requests.get(request_key)
            if sent_time is not None and fields["time"] >= sent_time:
                latencies.append(fields["time"] - sent_time)

    requests_sent = len(requests)
    responses_received = len(latencies)
    average_latency_ticks = (
        float(sum(latencies)) / responses_received if responses_received else 0.0
    )
    average_latency_ms = None
    if ticks_per_second:
        average_latency_ms = average_latency_ticks * 1000.0 / ticks_per_second

    return {
        "mode": "request_response",
        "ticks_per_second": ticks_per_second,
        "requests_sent": requests_sent,
        "responses_received": responses_received,
        "packet_reception_rate": (
            float(responses_received) / requests_sent if requests_sent else 0.0
        ),
        "latencies_ticks": latencies,
        "average_latency_ticks": average_latency_ticks,
        "average_latency_ms": average_latency_ms,
    }


def _analyze_data(lines, ticks_per_second):
    sends = {}
    total = _new_bucket()
    per_origin = defaultdict(_new_bucket)
    per_cluster = defaultdict(_new_bucket)
    per_data_type = defaultdict(_new_bucket)
    per_phase = defaultdict(_new_bucket)
    forward_count_by_node = defaultdict(int)
    drop_count_by_reason = defaultdict(int)
    current_phase = "normal"

    for line in lines:
        phase_match = PHASE_RE.search(line)
        if phase_match:
            fields = _parse_fields(phase_match.group("fields"))
            current_phase = fields.get("name", current_phase)
            continue

        event_match = EVENT_RE.search(line)
        if not event_match:
            continue

        kind = event_match.group("kind")
        if kind not in {"DATA_SEND", "DATA_FORWARD", "DATA_DELIVERED", "DATA_DROP"}:
            continue

        fields = _parse_fields(event_match.group("fields"))
        if kind == "DATA_SEND":
            required = {"time", "origin", "seq"}
            if not required.issubset(fields):
                continue
            key = _data_key(fields)
            sends[key] = {
                "time": fields["time"],
                "origin": fields["origin"],
                "cluster": fields.get("cluster", 0),
                "data_type": fields.get("data_type", 0),
                "phase": current_phase,
            }
            _add_sent(total)
            _add_sent(per_origin[fields["origin"]])
            _add_sent(per_cluster[fields.get("cluster", 0)])
            _add_sent(per_data_type[fields.get("data_type", 0)])
            _add_sent(per_phase[current_phase])
        elif kind == "DATA_FORWARD":
            if "src" in fields:
                forward_count_by_node[fields["src"]] += 1
        elif kind == "DATA_DROP":
            if "reason" in fields:
                drop_count_by_reason[fields["reason"]] += 1
        elif kind == "DATA_DELIVERED":
            required = {"time", "origin", "seq"}
            if not required.issubset(fields):
                continue
            sent = sends.get(_data_key(fields))
            if sent is None or fields["time"] < sent["time"]:
                continue
            latency = fields["time"] - sent["time"]
            hops = fields.get("hop_count", 0)
            _add_delivery(total, latency, hops)
            _add_delivery(per_origin[sent["origin"]], latency, hops)
            _add_delivery(per_cluster[sent["cluster"]], latency, hops)
            _add_delivery(per_data_type[sent["data_type"]], latency, hops)
            _add_delivery(per_phase[sent["phase"]], latency, hops)

    summary = _bucket_summary(total, ticks_per_second)
    summary.update({
        "mode": "data",
        "ticks_per_second": ticks_per_second,
        "data_sent": summary["sent"],
        "data_delivered": summary["delivered"],
        "requests_sent": summary["sent"],
        "responses_received": summary["delivered"],
        "per_origin": {
            key: _bucket_summary(value, ticks_per_second)
            for key, value in sorted(per_origin.items())
        },
        "per_cluster": {
            key: _bucket_summary(value, ticks_per_second)
            for key, value in sorted(per_cluster.items())
        },
        "per_data_type": {
            key: _bucket_summary(value, ticks_per_second)
            for key, value in sorted(per_data_type.items())
        },
        "per_phase": {
            key: _bucket_summary(value, ticks_per_second)
            for key, value in sorted(per_phase.items())
        },
        "forward_count_by_node": dict(sorted(forward_count_by_node.items())),
        "drop_count_by_reason": dict(sorted(drop_count_by_reason.items())),
    })
    return summary


def analyze_lines(lines):
    lines = list(lines)
    ticks_per_second = None
    has_data_events = False

    for line in lines:
        ticks_match = TICKS_PER_SECOND_RE.search(line)
        if ticks_match:
            ticks_per_second = int(ticks_match.group("value"))
        event_match = EVENT_RE.search(line)
        if event_match and event_match.group("kind").startswith("DATA_"):
            has_data_events = True

    if has_data_events:
        return _analyze_data(lines, ticks_per_second)
    return _analyze_request_response(lines, ticks_per_second)


def _format_metric_group(title, group, key_name):
    lines = [title]
    for key, value in sorted(group.items()):
        lines.append(
            "{0}={1} sent={2} delivered={3} packet_reception_rate={4:.6f} average_latency_ticks={5:.3f} average_hops={6:.3f}".format(
                key_name,
                key,
                value["sent"],
                value["delivered"],
                value["packet_reception_rate"],
                value["average_latency_ticks"],
                value["average_hops"],
            )
        )
    return lines


def format_report(result):
    lines = ["Simulation log analysis"]
    if result.get("mode") == "data":
        lines.extend([
            "mode=data",
            "data_sent={0}".format(result["data_sent"]),
            "data_delivered={0}".format(result["data_delivered"]),
            "packet_reception_rate={0:.6f}".format(result["packet_reception_rate"]),
            "average_latency_ticks={0:.3f}".format(result["average_latency_ticks"]),
        ])
        if result["average_latency_ms"] is not None:
            lines.append("average_latency_ms={0:.6f}".format(result["average_latency_ms"]))
        lines.append("average_hops={0:.3f}".format(result["average_hops"]))
        if result["ticks_per_second"] is not None:
            lines.append("ticks_per_second={0}".format(result["ticks_per_second"]))
        lines.extend(_format_metric_group("Per-origin", result["per_origin"], "origin"))
        lines.extend(_format_metric_group("Per-cluster", result["per_cluster"], "cluster"))
        lines.extend(_format_metric_group("Per-data-type", result["per_data_type"], "data_type"))
        lines.extend(_format_metric_group("Per-phase", result["per_phase"], "phase"))
        lines.append("Forward-count-by-node")
        for node, count in sorted(result["forward_count_by_node"].items()):
            lines.append("node={0} forwards={1}".format(node, count))
        lines.append("Drop-count-by-reason")
        for reason, count in sorted(result["drop_count_by_reason"].items()):
            lines.append("reason={0} drops={1}".format(reason, count))
        return "\n".join(lines)

    lines.extend([
        "requests_sent={0}".format(result["requests_sent"]),
        "responses_received={0}".format(result["responses_received"]),
        "packet_reception_rate={0:.6f}".format(result["packet_reception_rate"]),
        "average_latency_ticks={0:.3f}".format(result["average_latency_ticks"]),
    ])
    if result["average_latency_ms"] is not None:
        lines.append("average_latency_ms={0:.6f}".format(result["average_latency_ms"]))
    if result["ticks_per_second"] is not None:
        lines.append("ticks_per_second={0}".format(result["ticks_per_second"]))
    return "\n".join(lines)


def main(argv=None):
    parser = argparse.ArgumentParser(description="Analyze TOSSIM request/response logs.")
    parser.add_argument("logfile", help="Path to the simulation log.")
    args = parser.parse_args(argv)

    with open(args.logfile, "r") as handle:
        result = analyze_lines(handle)

    print(format_report(result))
    return 0


if __name__ == "__main__":
    sys.exit(main())
