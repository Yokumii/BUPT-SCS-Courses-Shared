#!/usr/bin/env python2
# -*- coding: utf-8 -*-
from __future__ import print_function

import argparse
import os
import subprocess
import sys


SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
APP_DIR = os.path.join(SCRIPT_DIR, "RequestResponse")
DEFAULT_TOPOLOGY = os.path.join(SCRIPT_DIR, "request_response_topology.txt")
DEFAULT_LOG = os.path.join(SCRIPT_DIR, "logs", "request_response.log")
NOISE_FILE = "/opt/tinyos-main/tos/lib/tossim/noise/meyer-heavy.txt"
RELAY_LINKS = [(9, 10), (10, 9)]
BACKUP_LINKS = [
    (7, 10, -68.0),
    (8, 10, -69.0),
    (10, 7, -68.0),
    (10, 8, -69.0),
]
DEFAULT_FAILURE_TIME_MS = 60000
DEFAULT_BACKUP_TIME_MS = 120000


def load_topology(radio, topology_path, log_handle):
    print("SIM TOPOLOGY_FILE path={0}".format(topology_path), file=log_handle)
    with open(topology_path, "r") as handle:
        for line in handle:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            fields = line.split()
            src = int(fields[0])
            dst = int(fields[1])
            gain = float(fields[2])
            radio.add(src, dst, gain)
            print("SIM TOPOLOGY_EDGE src={0} dst={1} gain={2}".format(src, dst, gain),
                  file=log_handle)


def load_noise(tossim, node_count):
    readings = []
    with open(NOISE_FILE, "r") as handle:
        for line in handle:
            line = line.strip()
            if line:
                readings.append(int(line))

    for node_id in range(1, node_count + 1):
        node = tossim.getNode(node_id)
        for reading in readings:
            node.addNoiseTraceReading(reading)
        node.createNoiseModel()


def boot_nodes(tossim, node_count):
    for node_id in range(1, node_count + 1):
        tossim.getNode(node_id).bootAtTime(100001 + node_id * 700003)


def ticks_from_ms(ticks_per_second, milliseconds):
    return int((long(ticks_per_second) * long(milliseconds)) // 1000)


def disable_backup_links(radio, log_handle):
    for src, dst, _gain in BACKUP_LINKS:
        if radio.connected(src, dst):
            radio.remove(src, dst)
            print("SIM LINK_REMOVE time=0 src={0} dst={1} reason=backup_disabled_initial".format(
                src, dst), file=log_handle)


def remove_relay_links(radio, now, log_handle):
    for src, dst in RELAY_LINKS:
        if radio.connected(src, dst):
            radio.remove(src, dst)
            print("SIM LINK_REMOVE time={0} src={1} dst={2} reason=relay_failure".format(
                now, src, dst), file=log_handle)


def enable_backup_links(radio, now, log_handle):
    for src, dst, gain in BACKUP_LINKS:
        radio.add(src, dst, gain)
        print("SIM LINK_ADD time={0} src={1} dst={2} gain={3} reason=backup_enabled".format(
            now, src, dst, gain), file=log_handle)


def run_analysis(log_path):
    analyzer = os.path.join(SCRIPT_DIR, "analyze_log.py")
    try:
        subprocess.call(["python3", analyzer, log_path])
    except OSError:
        subprocess.call(["python", analyzer, log_path])


def main(argv=None):
    parser = argparse.ArgumentParser(description="Run the RequestResponse TOSSIM simulation.")
    parser.add_argument("--nodes", type=int, default=10, help="Number of nodes to boot.")
    parser.add_argument("--events", type=int, default=80000, help="Number of TOSSIM events.")
    parser.add_argument("--topology", default=DEFAULT_TOPOLOGY, help="Topology file path.")
    parser.add_argument("--log", default=DEFAULT_LOG, help="Log file path.")
    parser.add_argument("--failure-time-ms", type=int, default=DEFAULT_FAILURE_TIME_MS,
                        help="Relay failure time in milliseconds.")
    parser.add_argument("--backup-time-ms", type=int, default=DEFAULT_BACKUP_TIME_MS,
                        help="Backup link enable time in milliseconds.")
    parser.add_argument("--disable-dynamic-events", action="store_true",
                        help="Keep the loaded topology unchanged.")
    parser.add_argument("--skip-analysis", action="store_true", help="Only run simulation.")
    args = parser.parse_args(argv)

    if not os.path.exists(APP_DIR):
        raise SystemExit("Application directory not found: {0}".format(APP_DIR))

    log_dir = os.path.dirname(args.log)
    if log_dir and not os.path.exists(log_dir):
        os.makedirs(log_dir)

    os.chdir(APP_DIR)
    sys.path.insert(0, APP_DIR)

    from TOSSIM import Tossim

    tossim = Tossim([])
    radio = tossim.radio()

    with open(args.log, "w") as log_handle:
        print("SIM START app=RequestResponse nodes={0} events={1}".format(args.nodes, args.events),
              file=log_handle)
        ticks_per_second = tossim.ticksPerSecond()
        failure_time = ticks_from_ms(ticks_per_second, args.failure_time_ms)
        backup_time = ticks_from_ms(ticks_per_second, args.backup_time_ms)

        print("SIM TICKS_PER_SECOND value={0}".format(ticks_per_second), file=log_handle)
        if (args.failure_time_ms != DEFAULT_FAILURE_TIME_MS or
                args.backup_time_ms != DEFAULT_BACKUP_TIME_MS):
            print("SIM CONFIG_WARNING time=0 reason=dynamic_times_must_match_compiled_app failure_time_ms={0} backup_time_ms={1}".format(
                args.failure_time_ms, args.backup_time_ms), file=log_handle)
        print("SIM PHASE time=0 name=normal", file=log_handle)
        load_topology(radio, args.topology, log_handle)
        if not args.disable_dynamic_events:
            disable_backup_links(radio, log_handle)

        tossim.addChannel("RequestResponse", log_handle)
        tossim.addChannel("Boot", log_handle)

        load_noise(tossim, args.nodes)
        boot_nodes(tossim, args.nodes)

        failure_started = False
        backup_started = False
        for _ in xrange(args.events):
            tossim.runNextEvent()
            now = tossim.time()
            if not args.disable_dynamic_events and not failure_started and now >= failure_time:
                print("SIM PHASE time={0} name=relay_failure".format(now), file=log_handle)
                remove_relay_links(radio, now, log_handle)
                failure_started = True
            if not args.disable_dynamic_events and not backup_started and now >= backup_time:
                print("SIM PHASE time={0} name=backup_enabled".format(now), file=log_handle)
                enable_backup_links(radio, now, log_handle)
                backup_started = True

        print("SIM END time={0}".format(tossim.time()), file=log_handle)

    print("log={0}".format(args.log))
    if not args.skip_analysis:
        run_analysis(args.log)


if __name__ == "__main__":
    main()
