#include "Timer.h"
#include "RequestResponse.h"

module RequestResponseC @safe() {
  uses {
    interface Boot;
    interface SplitControl as AMControl;
    interface AMSend;
    interface Receive;
    interface Packet;
    interface Timer<TMilli> as RequestTimer;
  }
}
implementation {
  message_t packet;
  bool busy = FALSE;
  uint16_t seq = 0;

  bool isSensorNode() {
    return TOS_NODE_ID >= 1 && TOS_NODE_ID <= 6;
  }

  bool relayFailureActive() {
    return sim_time() >= REQUEST_RESPONSE_FAILURE_TIME_TICKS &&
           sim_time() < REQUEST_RESPONSE_BACKUP_TIME_TICKS;
  }

  bool backupActive() {
    return sim_time() >= REQUEST_RESPONSE_BACKUP_TIME_TICKS;
  }

  uint8_t clusterOf(uint8_t node) {
    if (node >= 1 && node <= 3) {
      return 1;
    }
    if (node >= 4 && node <= 6) {
      return 2;
    }
    if (node == 7) {
      return 1;
    }
    if (node == 8) {
      return 2;
    }
    return 0;
  }

  uint8_t dataTypeOf(uint8_t node) {
    return ((node - 1) % 3) + 1;
  }

  uint8_t routeNextHop() {
    if (TOS_NODE_ID >= 1 && TOS_NODE_ID <= 3) {
      return 7;
    }
    if (TOS_NODE_ID >= 4 && TOS_NODE_ID <= 6) {
      return 8;
    }
    if (TOS_NODE_ID == 7 || TOS_NODE_ID == 8) {
      if (backupActive()) {
        return REQUEST_RESPONSE_SINK;
      }
      return 9;
    }
    if (TOS_NODE_ID == 9) {
      if (relayFailureActive()) {
        return 0;
      }
      return REQUEST_RESPONSE_SINK;
    }
    return 0;
  }

  uint8_t dropReasonForNoRoute() {
    if (TOS_NODE_ID == 9 && relayFailureActive()) {
      return REQUEST_RESPONSE_DROP_RELAY_FAILURE;
    }
    return REQUEST_RESPONSE_DROP_NO_ROUTE;
  }

  void scheduleNextData() {
    if (isSensorNode()) {
      call RequestTimer.startOneShot(REQUEST_RESPONSE_INTERVAL_MS + (TOS_NODE_ID * 37));
    }
  }

  void logDrop(uint8_t dst,
               uint8_t origin,
               uint8_t finalDst,
               uint16_t packetSeq,
               uint8_t hopCount,
               uint8_t cluster,
               uint8_t dataType,
               uint8_t reason) {
    dbg("RequestResponse",
        "APP DATA_DROP time=%llu src=%hu dst=%hhu origin=%hhu final_dst=%hhu seq=%hu hop_count=%hhu cluster=%hhu data_type=%hhu reason=%hhu\n",
        sim_time(), TOS_NODE_ID, dst, origin, finalDst, packetSeq, hopCount,
        cluster, dataType, reason);
  }

  void sendSensorData() {
    request_response_msg_t* payload = NULL;
    uint8_t nextHop = routeNextHop();
    uint8_t cluster = clusterOf(TOS_NODE_ID);
    uint8_t dataType = dataTypeOf(TOS_NODE_ID);

    if (!isSensorNode()) {
      return;
    }

    if (nextHop == 0) {
      logDrop(0, TOS_NODE_ID, REQUEST_RESPONSE_SINK, seq, 0, cluster,
              dataType, REQUEST_RESPONSE_DROP_NO_ROUTE);
      return;
    }

    if (busy) {
      logDrop(nextHop, TOS_NODE_ID, REQUEST_RESPONSE_SINK, seq, 0, cluster,
              dataType, REQUEST_RESPONSE_DROP_BUSY);
      return;
    }

    payload = (request_response_msg_t*)call Packet.getPayload(
      &packet,
      sizeof(request_response_msg_t)
    );
    if (payload == NULL) {
      logDrop(nextHop, TOS_NODE_ID, REQUEST_RESPONSE_SINK, seq, 0, cluster,
              dataType, REQUEST_RESPONSE_DROP_NO_PAYLOAD);
      return;
    }

    payload->type = REQUEST_RESPONSE_DATA;
    payload->origin = TOS_NODE_ID;
    payload->final_dst = REQUEST_RESPONSE_SINK;
    payload->next_hop = nextHop;
    payload->previous_hop = TOS_NODE_ID;
    payload->hop_count = 0;
    payload->cluster = cluster;
    payload->data_type = dataType;
    payload->seq = seq;
    payload->value = (uint16_t)(TOS_NODE_ID * 100 + seq);

    if (call AMSend.send(nextHop, &packet, sizeof(request_response_msg_t)) == SUCCESS) {
      dbg("RequestResponse",
          "APP DATA_SEND time=%llu src=%hu dst=%hhu origin=%hu final_dst=%hhu seq=%hu hop_count=0 cluster=%hhu data_type=%hhu\n",
          sim_time(), TOS_NODE_ID, nextHop, TOS_NODE_ID, REQUEST_RESPONSE_SINK,
          seq, cluster, dataType);
      busy = TRUE;
      seq++;
    }
    else {
      logDrop(nextHop, TOS_NODE_ID, REQUEST_RESPONSE_SINK, seq, 0, cluster,
              dataType, REQUEST_RESPONSE_DROP_SEND_FAILED);
    }
  }

  void forwardData(request_response_msg_t* received) {
    request_response_msg_t* payload = NULL;
    uint8_t nextHop = routeNextHop();
    uint8_t nextHopCount = received->hop_count + 1;

    if (nextHop == 0) {
      logDrop(0, received->origin, received->final_dst, received->seq,
              nextHopCount, received->cluster, received->data_type,
              dropReasonForNoRoute());
      return;
    }

    if (busy) {
      logDrop(nextHop, received->origin, received->final_dst, received->seq,
              nextHopCount, received->cluster, received->data_type,
              REQUEST_RESPONSE_DROP_BUSY);
      return;
    }

    payload = (request_response_msg_t*)call Packet.getPayload(
      &packet,
      sizeof(request_response_msg_t)
    );
    if (payload == NULL) {
      logDrop(nextHop, received->origin, received->final_dst, received->seq,
              nextHopCount, received->cluster, received->data_type,
              REQUEST_RESPONSE_DROP_NO_PAYLOAD);
      return;
    }

    payload->type = received->type;
    payload->origin = received->origin;
    payload->final_dst = received->final_dst;
    payload->next_hop = nextHop;
    payload->previous_hop = TOS_NODE_ID;
    payload->hop_count = nextHopCount;
    payload->cluster = received->cluster;
    payload->data_type = received->data_type;
    payload->seq = received->seq;
    payload->value = received->value;

    if (call AMSend.send(nextHop, &packet, sizeof(request_response_msg_t)) == SUCCESS) {
      dbg("RequestResponse",
          "APP DATA_FORWARD time=%llu src=%hu dst=%hhu origin=%hhu final_dst=%hhu seq=%hu hop_count=%hhu cluster=%hhu data_type=%hhu\n",
          sim_time(), TOS_NODE_ID, nextHop, received->origin, received->final_dst,
          received->seq, nextHopCount, received->cluster, received->data_type);
      busy = TRUE;
    }
    else {
      logDrop(nextHop, received->origin, received->final_dst, received->seq,
              nextHopCount, received->cluster, received->data_type,
              REQUEST_RESPONSE_DROP_SEND_FAILED);
    }
  }

  event void Boot.booted() {
    dbg("RequestResponse", "APP BOOT time=%llu node=%hu\n", sim_time(), TOS_NODE_ID);
    call AMControl.start();
  }

  event void AMControl.startDone(error_t err) {
    if (err == SUCCESS) {
      if (isSensorNode()) {
        call RequestTimer.startOneShot(200 + (TOS_NODE_ID * 53));
      }
    }
    else {
      call AMControl.start();
    }
  }

  event void AMControl.stopDone(error_t err) {
  }

  event message_t* Receive.receive(message_t* msg, void* data, uint8_t len) {
    request_response_msg_t* payload = (request_response_msg_t*)data;

    if (len != sizeof(request_response_msg_t)) {
      return msg;
    }

    if (payload->type != REQUEST_RESPONSE_DATA) {
      return msg;
    }

    if (payload->next_hop != TOS_NODE_ID) {
      return msg;
    }

    if (payload->final_dst == TOS_NODE_ID) {
      dbg("RequestResponse",
          "APP DATA_DELIVERED time=%llu src=%hhu dst=%hu origin=%hhu final_dst=%hhu seq=%hu hop_count=%hhu cluster=%hhu data_type=%hhu\n",
          sim_time(), payload->previous_hop, TOS_NODE_ID, payload->origin,
          payload->final_dst, payload->seq, (uint8_t)(payload->hop_count + 1),
          payload->cluster, payload->data_type);
    }
    else {
      forwardData(payload);
    }

    return msg;
  }

  event void AMSend.sendDone(message_t* msg, error_t err) {
    if (&packet == msg) {
      busy = FALSE;
      scheduleNextData();
    }
  }

  event void RequestTimer.fired() {
    sendSensorData();
    if (!busy) {
      scheduleNextData();
    }
  }
}
