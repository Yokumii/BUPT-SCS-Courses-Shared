#ifndef REQUEST_RESPONSE_H
#define REQUEST_RESPONSE_H

enum {
  AM_REQUEST_RESPONSE_MSG = 93,
  REQUEST_RESPONSE_NODE_COUNT = 10,
  REQUEST_RESPONSE_DATA = 1,
  REQUEST_RESPONSE_INTERVAL_MS = 512,
  REQUEST_RESPONSE_SINK = 10,
  REQUEST_RESPONSE_DROP_NO_ROUTE = 1,
  REQUEST_RESPONSE_DROP_BUSY = 2,
  REQUEST_RESPONSE_DROP_SEND_FAILED = 3,
  REQUEST_RESPONSE_DROP_NO_PAYLOAD = 4,
  REQUEST_RESPONSE_DROP_RELAY_FAILURE = 5,
};

#define REQUEST_RESPONSE_FAILURE_TIME_TICKS 600000000000ULL
#define REQUEST_RESPONSE_BACKUP_TIME_TICKS 1200000000000ULL

typedef nx_struct request_response_msg {
  nx_uint8_t type;
  nx_uint8_t origin;
  nx_uint8_t final_dst;
  nx_uint8_t next_hop;
  nx_uint8_t previous_hop;
  nx_uint8_t hop_count;
  nx_uint8_t cluster;
  nx_uint8_t data_type;
  nx_uint16_t seq;
  nx_uint16_t value;
} request_response_msg_t;

#endif
