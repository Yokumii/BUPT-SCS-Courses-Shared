#include "RequestResponse.h"

configuration RequestResponseAppC {}
implementation {
  components MainC, RequestResponseC as App, ActiveMessageC;
  components new AMSenderC(AM_REQUEST_RESPONSE_MSG);
  components new AMReceiverC(AM_REQUEST_RESPONSE_MSG);
  components new TimerMilliC() as RequestTimer;

  App.Boot -> MainC.Boot;
  App.AMControl -> ActiveMessageC;
  App.AMSend -> AMSenderC;
  App.Receive -> AMReceiverC;
  App.Packet -> AMSenderC;
  App.RequestTimer -> RequestTimer;
}
