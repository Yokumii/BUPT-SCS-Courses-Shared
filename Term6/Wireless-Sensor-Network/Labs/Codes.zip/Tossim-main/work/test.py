#!/usr/bin/env python2
# -*- coding: utf-8 -*-
# RadioCountToLeds TOSSIM simulation. Run from anywhere in the container:
#   make -C /opt/tinyos-main/apps/RadioCountToLeds micaz sim   # once per source change
#   python2 /work/test.py
import os
import sys

APP_DIR = "/opt/tinyos-main/apps/RadioCountToLeds"
NOISE_FILE = "/opt/tinyos-main/tos/lib/tossim/noise/meyer-heavy.txt"
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
TOPO_FILE = os.path.join(SCRIPT_DIR, "topo.txt")

# _TOSSIMmodule.so and TOSSIM.py live in APP_DIR after `make micaz sim`
os.chdir(APP_DIR)
sys.path.insert(0, APP_DIR)

from TOSSIM import *

t = Tossim([])
r = t.radio()

print "Loading topology from", TOPO_FILE
with open(TOPO_FILE, "r") as f:
    for line in f:
        s = line.split()
        if s:
            print " ", s[0], " ", s[1], " ", s[2]
            r.add(int(s[0]), int(s[1]), float(s[2]))

t.addChannel("RadioCountToLedsC", sys.stdout)
t.addChannel("Boot", sys.stdout)
# Lower-layer diagnostic channels.
# Names verified against actual `dbg(...)` calls in:
#   tos/chips/cc2420, tos/platforms/micaz/sim, tos/lib/tossim
# Useful when sendDone never fires and you need to see where the
# packet stalls between AM and the simulated radio medium.
for _ch in ("AM",
            "Csma",                # CC2420 CSMA / send arbitration
            "CC2420Config",
            "CC2420PacketP",
            "Packet",
            "PacketLink",          # retransmission layer
            "UniqueSend",          # outgoing packet IDs
            "UniqueReceive",       # incoming packet IDs
            "Acks",
            "TossimPacketModelC",  # TOSSIM packet medium
            "CpmModelC",           # CPM noise / reception model
            "Gain",                # path-loss math
            "Scheduler",           # task scheduler
            "SimMoteP",
            "Tossim"):
    t.addChannel(_ch, sys.stdout)

print "Loading noise trace from", NOISE_FILE
with open(NOISE_FILE, "r") as noise:
    for line in noise:
        s = line.strip()
        if s:
            val = int(s)
            for i in range(1, 4):
                t.getNode(i).addNoiseTraceReading(val)

for i in range(1, 4):
    print "Creating noise model for", i
    t.getNode(i).createNoiseModel()

t.getNode(1).bootAtTime(100001)
t.getNode(2).bootAtTime(800008)
t.getNode(3).bootAtTime(1800009)

for _ in range(10000):
    t.runNextEvent()
