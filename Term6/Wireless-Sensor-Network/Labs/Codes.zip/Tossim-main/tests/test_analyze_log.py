import textwrap
import unittest

from work.analyze_log import analyze_lines


class AnalyzeLogTest(unittest.TestCase):
    def test_computes_request_response_delivery_ratio_and_average_latency(self):
        log = textwrap.dedent(
            """
            SIM TICKS_PER_SECOND value=4000000
            0:0:0.100000000 DEBUG (1): APP REQUEST_SEND time=1000 src=1 dst=2 seq=7 target=2
            0:0:0.100100000 DEBUG (2): APP REQUEST_RECV time=1100 src=1 dst=2 seq=7 target=2
            0:0:0.100300000 DEBUG (1): APP RESPONSE_RECV time=1300 src=2 dst=1 seq=7 target=2
            0:0:0.200000000 DEBUG (2): APP REQUEST_SEND time=2000 src=2 dst=3 seq=8 target=3
            0:0:0.200400000 DEBUG (2): APP RESPONSE_RECV time=2400 src=3 dst=2 seq=8 target=3
            0:0:0.300000000 DEBUG (3): APP REQUEST_SEND time=3000 src=3 dst=4 seq=9 target=4
            """
        ).strip().splitlines()

        result = analyze_lines(log)

        self.assertEqual(result["requests_sent"], 3)
        self.assertEqual(result["responses_received"], 2)
        self.assertAlmostEqual(result["packet_reception_rate"], 2.0 / 3.0)
        self.assertEqual(result["latencies_ticks"], [300, 400])
        self.assertEqual(result["average_latency_ticks"], 350.0)
        self.assertAlmostEqual(result["average_latency_ms"], 0.0875)

    def test_computes_data_delivery_metrics(self):
        log = textwrap.dedent(
            """
            SIM TICKS_PER_SECOND value=1000000
            SIM PHASE time=0 name=normal
            0:0:0.001 DEBUG (1): APP DATA_SEND time=1000 src=1 dst=7 origin=1 final_dst=10 seq=1 hop_count=0 cluster=1 data_type=1
            0:0:0.002 DEBUG (7): APP DATA_FORWARD time=2000 src=7 dst=9 origin=1 final_dst=10 seq=1 hop_count=1 cluster=1 data_type=1
            0:0:0.003 DEBUG (9): APP DATA_FORWARD time=3000 src=9 dst=10 origin=1 final_dst=10 seq=1 hop_count=2 cluster=1 data_type=1
            0:0:0.004 DEBUG (10): APP DATA_DELIVERED time=5000 src=9 dst=10 origin=1 final_dst=10 seq=1 hop_count=3 cluster=1 data_type=1
            0:0:0.005 DEBUG (2): APP DATA_SEND time=6000 src=2 dst=7 origin=2 final_dst=10 seq=2 hop_count=0 cluster=1 data_type=2
            0:0:0.006 DEBUG (7): APP DATA_DROP time=7000 src=7 dst=9 origin=2 final_dst=10 seq=2 hop_count=1 cluster=1 data_type=2 reason=2
            """
        ).strip().splitlines()

        result = analyze_lines(log)

        self.assertEqual(result["mode"], "data")
        self.assertEqual(result["data_sent"], 2)
        self.assertEqual(result["data_delivered"], 1)
        self.assertAlmostEqual(result["packet_reception_rate"], 0.5)
        self.assertEqual(result["latencies_ticks"], [4000])
        self.assertEqual(result["average_latency_ticks"], 4000.0)
        self.assertEqual(result["average_latency_ms"], 4.0)
        self.assertEqual(result["average_hops"], 3.0)
        self.assertEqual(result["per_origin"][1]["sent"], 1)
        self.assertEqual(result["per_origin"][1]["delivered"], 1)
        self.assertEqual(result["per_origin"][2]["sent"], 1)
        self.assertEqual(result["per_origin"][2]["delivered"], 0)
        self.assertEqual(result["per_cluster"][1]["sent"], 2)
        self.assertEqual(result["per_cluster"][1]["delivered"], 1)
        self.assertEqual(result["forward_count_by_node"], {7: 1, 9: 1})
        self.assertEqual(result["drop_count_by_reason"], {2: 1})

    def test_groups_data_metrics_by_phase(self):
        log = textwrap.dedent(
            """
            SIM TICKS_PER_SECOND value=1000000
            SIM PHASE time=0 name=normal
            APP DATA_SEND time=1000 src=1 dst=7 origin=1 final_dst=10 seq=1 hop_count=0 cluster=1 data_type=1
            APP DATA_DELIVERED time=4000 src=9 dst=10 origin=1 final_dst=10 seq=1 hop_count=3 cluster=1 data_type=1
            SIM PHASE time=5000 name=relay_failure
            APP DATA_SEND time=6000 src=4 dst=8 origin=4 final_dst=10 seq=1 hop_count=0 cluster=2 data_type=1
            APP DATA_DROP time=7000 src=9 dst=0 origin=4 final_dst=10 seq=1 hop_count=2 cluster=2 data_type=1 reason=5
            SIM PHASE time=8000 name=backup_enabled
            APP DATA_SEND time=9000 src=5 dst=8 origin=5 final_dst=10 seq=1 hop_count=0 cluster=2 data_type=2
            APP DATA_DELIVERED time=12000 src=8 dst=10 origin=5 final_dst=10 seq=1 hop_count=2 cluster=2 data_type=2
            """
        ).strip().splitlines()

        result = analyze_lines(log)

        self.assertEqual(result["per_phase"]["normal"]["sent"], 1)
        self.assertEqual(result["per_phase"]["normal"]["delivered"], 1)
        self.assertEqual(result["per_phase"]["relay_failure"]["sent"], 1)
        self.assertEqual(result["per_phase"]["relay_failure"]["delivered"], 0)
        self.assertEqual(result["per_phase"]["backup_enabled"]["sent"], 1)
        self.assertEqual(result["per_phase"]["backup_enabled"]["delivered"], 1)
        self.assertEqual(result["drop_count_by_reason"], {5: 1})


if __name__ == "__main__":
    unittest.main()
