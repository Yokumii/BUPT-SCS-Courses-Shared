# Tossim

基于 Ubuntu 16.04 容器，从源码编译 nesC 与 `tinyos-main/tools`，用于运行 TOSSIM 仿真。

---

## 目录结构

```
.
├── Dockerfile          # 镜像构建脚本
├── README.md
└── work/               # 挂载到容器 /work
    ├── test.py                         # RadioCountToLeds 多节点仿真脚本
    ├── topo.txt                        # RadioCountToLeds 拓扑：3 节点全互连
    ├── RequestResponse/                # 分簇多跳传感器网络仿真应用
    ├── sim_request_response.py         # 分簇多跳 TOSSIM 仿真脚本
    ├── analyze_log.py                  # 仿真日志分析脚本
    └── request_response_topology.txt   # 10 节点分簇多跳拓扑
```

## Quick Start

### 1. 构建镜像

```bash
docker build --no-cache -t tinyos-sim-src16 .
```

首次构建 10–30 分钟。镜像里已包含两个关键 patch（GCC C99 inline + ARM64 signed char），无需手动处理。

### 2. 运行容器

```bash
mkdir -p ./work
docker run -it --name tinyos-sim -v "$(pwd)/work":/work tinyos-sim-src16
```

宿主机 `./work/` ↔ 容器内 `/work/`，双向同步。

容器管理：

```bash
docker start -ai tinyos-sim     # 重新进入
docker stop tinyos-sim
docker rm   tinyos-sim
```

### 3. 跑示例

仓库已附带 `work/test.py` 和 `work/topo.txt`，对应 RadioCountToLeds 多节点仿真。

```bash
# 容器内
cd /opt/tinyos-main/apps/RadioCountToLeds
make micaz sim                         # 首次或源码改动后必跑
python2 /work/test.py
```

### 4. 跑分簇多跳传感器网络实验

`RequestResponse` 实现 10 个节点的分簇多跳数据上报。节点 1 到 6 周期性产生传感器数据，节点 7 和 8 作为簇头，节点 9 作为中继节点，节点 10 作为汇聚节点。仿真脚本记录完整通信日志，并在仿真结束后计算收包率、端到端时延、跳数、分簇统计和故障阶段统计。

```bash
# 容器内
cd /work/RequestResponse
make micaz sim

cd /work
python2 /work/sim_request_response.py --nodes 10 --events 80000
```

单独分析已有日志：

```bash
python3 work/analyze_log.py work/logs/request_response.log
```

---

## 分簇多跳传感器网络实验

### 实验目标

实验构建一个 10 节点传感器网络，在 TOSSIM 中观察普通传感器节点、簇头节点、中继节点和汇聚节点之间的数据上报过程。仿真过程中所有应用层事件写入日志，仿真结束后通过日志计算收包率、端到端时延、平均跳数、按源节点统计、按分簇统计和按仿真阶段统计。

统计定义如下：

```text
收包率 = 汇聚节点收到的数据包个数 / 普通传感器发出的数据包个数
端到端时延 = 汇聚节点收到数据包的时间 - 普通传感器发出数据包的时间
平均时延 = 所有成功送达数据包端到端时延的平均值
平均跳数 = 成功送达数据包的 hop_count 平均值
```

### 实验设置

实验运行环境和仿真参数如下。

| 项目 | 设置 |
|---|---|
| 容器镜像 | `tinyos-sim-src16` |
| 容器系统 | Ubuntu 16.04 |
| TinyOS 平台 | `micaz` |
| 仿真器 | TOSSIM |
| 应用目录 | `work/RequestResponse` |
| 仿真脚本 | `work/sim_request_response.py` |
| 拓扑文件 | `work/request_response_topology.txt` |
| 日志文件 | `work/logs/request_response.log` |
| 噪声文件 | `/opt/tinyos-main/tos/lib/tossim/noise/meyer-heavy.txt` |
| 节点数量 | 10 |
| 仿真事件数 | 80000 |
| 传感器发送周期 | `512 ms + TOS_NODE_ID * 37 ms` |
| 节点启动时间 | `100001 + TOS_NODE_ID * 700003` ticks |
| 故障开始时间 | 60000 ms |
| 备用链路启用时间 | 120000 ms |
| ticks per second | `10000000000` |

节点角色如下。

| 节点 | 角色 | 行为 |
|---|---|---|
| 1, 2, 3 | A 区普通传感器 | 周期产生数据，发往簇头 7 |
| 4, 5, 6 | B 区普通传感器 | 周期产生数据，发往簇头 8 |
| 7 | A 区簇头 | 转发 A 区数据 |
| 8 | B 区簇头 | 转发 B 区数据 |
| 9 | 中继节点 | 正常阶段转发簇头数据到汇聚节点 10 |
| 10 | 汇聚节点 | 接收最终数据并记录送达事件 |

### 拓扑与链路参数

拓扑文件为 `work/request_response_topology.txt`。本实验使用 10 个节点和 22 条有向边，链路增益范围为 `-50.0 dBm` 到 `-69.0 dBm`。较强链路用于簇内通信和中继通信，较弱链路用于备用传输，体现链路质量差异对收包率和时延的影响。

```mermaid
flowchart LR
    subgraph ClusterA["Cluster A"]
        N1["1 Sensor"] -->|"-50 dBm"| CH7["7 Cluster Head"]
        N2["2 Sensor"] -->|"-52 dBm"| CH7
        N3["3 Sensor"] -->|"-55 dBm"| CH7
    end

    subgraph ClusterB["Cluster B"]
        N4["4 Sensor"] -->|"-51 dBm"| CH8["8 Cluster Head"]
        N5["5 Sensor"] -->|"-54 dBm"| CH8
        N6["6 Sensor"] -->|"-57 dBm"| CH8
    end

    CH7 -->|"-58 dBm"| R9["9 Relay"]
    CH8 -->|"-62 dBm"| R9
    R9 -->|"-56 dBm"| S10["10 Sink"]
    CH7 -. "backup -68 dBm" .-> S10
    CH8 -. "backup -69 dBm" .-> S10
```

链路参数如下。表中双向表示拓扑文件中包含两个方向的有向边。

| 链路 | 增益 | 作用 |
|---|---:|---|
| 1 <-> 7 | `-50.0 dBm` | A 区传感器到簇头 |
| 2 <-> 7 | `-52.0 dBm` | A 区传感器到簇头 |
| 3 <-> 7 | `-55.0 dBm` | A 区传感器到簇头 |
| 4 <-> 8 | `-51.0 dBm` | B 区传感器到簇头 |
| 5 <-> 8 | `-54.0 dBm` | B 区传感器到簇头 |
| 6 <-> 8 | `-57.0 dBm` | B 区传感器到簇头 |
| 7 <-> 9 | `-58.0 dBm` | A 区簇头到中继 |
| 8 <-> 9 | `-62.0 dBm` | B 区簇头到中继 |
| 9 <-> 10 | `-56.0 dBm` | 中继到汇聚节点 |
| 7 <-> 10 | `-68.0 dBm` | A 区备用弱链路 |
| 8 <-> 10 | `-69.0 dBm` | B 区备用弱链路 |

仿真脚本启动后会先加载完整拓扑，再移除备用链路，使正常阶段只能通过中继节点 9 到达汇聚节点 10。60000 ms 后脚本移除 `9 <-> 10` 链路，模拟中继到汇聚节点之间的链路故障。120000 ms 后脚本启用 `7 <-> 10` 和 `8 <-> 10` 备用弱链路，簇头改为直连汇聚节点。

### 节点行为

所有节点运行同一个 TinyOS 应用 `RequestResponse`。应用根据 `TOS_NODE_ID` 区分节点角色。

普通传感器节点周期性发送数据包。簇头和中继节点收到目标为自身的数据包后，根据静态路由继续转发。汇聚节点收到最终目标为自身的数据包后记录 `DATA_DELIVERED`。

数据包包含以下字段：

```text
type          包类型，当前为 DATA
origin        数据源节点
final_dst     最终目标节点，固定为 10
next_hop      当前下一跳节点
previous_hop  当前发送节点
hop_count     已经过的跳数
cluster       分簇编号
data_type     数据类型，按节点编号分为 1、2、3
seq           源节点内递增序号
value         负载数据
```

路由规则如下。

| 当前节点 | 正常阶段下一跳 | 故障阶段下一跳 | 备用阶段下一跳 |
|---|---:|---:|---:|
| 1, 2, 3 | 7 | 7 | 7 |
| 4, 5, 6 | 8 | 8 | 8 |
| 7 | 9 | 9 | 10 |
| 8 | 9 | 9 | 10 |
| 9 | 10 | 无可用下一跳 | 10 |
| 10 | 最终接收 | 最终接收 | 最终接收 |

### 日志格式

仿真日志默认写入：

```text
work/logs/request_response.log
```

日志中关键事件如下：

```text
SIM PHASE          仿真阶段切换
SIM LINK_REMOVE    仿真脚本移除链路
SIM LINK_ADD       仿真脚本启用链路
APP DATA_SEND      普通传感器发出数据
APP DATA_FORWARD   簇头或中继节点转发数据
APP DATA_DELIVERED 汇聚节点收到最终数据
APP DATA_DROP      应用层丢弃数据
```

分析脚本使用 `(origin, data_type, seq)` 匹配 `DATA_SEND` 和 `DATA_DELIVERED`，由此计算端到端时延。`DATA_FORWARD` 用于统计各转发节点负载，`DATA_DROP` 用于统计丢弃原因。

丢弃原因编码如下。

| reason | 含义 |
|---:|---|
| 1 | 无可用路由 |
| 2 | 节点发送缓冲区忙 |
| 3 | `AMSend.send` 返回失败 |
| 4 | 无法获取消息负载缓冲区 |
| 5 | 中继故障阶段无法继续转发 |

### 实验结果

本次使用 `80000` 个 TOSSIM 事件运行仿真，分析输出摘要如下：

```text
Simulation log analysis
mode=data
data_sent=2701
data_delivered=1863
packet_reception_rate=0.689745
average_latency_ticks=140620591.808
average_latency_ms=14.062059
average_hops=2.262
ticks_per_second=10000000000
```

按分簇统计如下：

```text
cluster=1 sent=1467 delivered=1007 packet_reception_rate=0.686435 average_latency_ticks=141484212.263 average_hops=2.259
cluster=2 sent=1234 delivered=856 packet_reception_rate=0.693679 average_latency_ticks=139604627.091 average_hops=2.266
```

按仿真阶段统计如下：

```text
phase=normal sent=575 delivered=489 packet_reception_rate=0.850435 average_latency_ticks=188258033.726 average_hops=3.000
phase=relay_failure sent=573 delivered=0 packet_reception_rate=0.000000 average_latency_ticks=0.000 average_hops=0.000
phase=backup_enabled sent=1553 delivered=1374 packet_reception_rate=0.884739 average_latency_ticks=123666655.056 average_hops=2.000
```

转发节点负载如下：

```text
node=7 forwards=1373
node=8 forwards=1160
node=9 forwards=501
```

### 结果分析

本次仿真总共发出 `2701` 个数据包，汇聚节点成功收到 `1863` 个，整体收包率为 `68.97%`，平均端到端时延约 `14.06 ms`，平均跳数为 `2.262`。

正常阶段中，数据路径为传感器到簇头、簇头到中继、中继到汇聚节点，成功送达数据包的平均跳数为 `3.000`，收包率为 `85.04%`。该阶段体现了分簇多跳拓扑在稳定链路下的数据汇聚能力。

故障阶段中，仿真脚本移除 `9 <-> 10` 链路，应用层中继节点 9 也进入故障阶段，无法继续转发到汇聚节点。该阶段发出 `573` 个数据包，成功送达 `0` 个，收包率为 `0.00%`，日志中记录 `reason=5` 的丢弃事件 `522` 次。该阶段用于展示中继到汇聚节点链路对多跳网络连通性的影响。

备用阶段中，仿真脚本启用 `7 <-> 10` 和 `8 <-> 10` 弱链路，簇头节点改为直连汇聚节点。该阶段发出 `1553` 个数据包，成功送达 `1374` 个，收包率恢复到 `88.47%`，平均跳数下降到 `2.000`。虽然备用链路增益较弱，但路径更短，因此平均时延从正常阶段的约 `18.83 ms` 降低到约 `12.37 ms`。

分簇统计显示，A 区和 B 区收包率接近，分别为 `68.64%` 和 `69.37%`。节点 7 与节点 8 的转发次数分别为 `1373` 和 `1160`，说明簇头节点承担了明显高于普通传感器节点的通信负载。节点 9 的转发次数为 `501`，主要来自正常阶段；故障阶段后该节点无法继续完成到汇聚节点的转发。

整体来看，该实验满足不少于 3 个节点的传感器网络数据发送与接收要求，并通过分簇、多跳、链路质量差异、阶段性故障和备用链路展示了更复杂的网络行为。日志分析覆盖全网指标、分簇指标、阶段指标和节点转发负载，能够支撑对收包率与时延变化的定量分析。

---

## Q&A

**Q：`from TOSSIM import *` 报 `undefined symbol: __nesc_atomic_end`**

**A**：未带 `-fgnu89-inline`，导致 nesC inline 函数编译成普通函数，链接时找不到。已写进 Dockerfile patch；旧镜像重建即可。

**Q：仿真在跑、`timer fired` 一直触发，但永远收不到包、`packet sent` 只出现一次？**

**A**：ARM64 / Apple Silicon 容器下 `char` 默认无符号，导致噪声值被读成正数、CCA 永远不通过。需要 `-fsigned-char`，已写进 Dockerfile patch；旧镜像重建即可。

---

## License

[MIT License](LICENSE)
